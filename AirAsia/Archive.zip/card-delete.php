<?php
// Include database connection
include 'db-connect.php';

// Get card ID from URL
$cardId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($cardId > 0) {
    $sql = "DELETE FROM GIFTCARD WHERE cardId = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cardId);
    $stmt->execute();
    $conn->close();
}

// Redirect to card list after deletion
header("Location: card-list.php");
exit;
?>
